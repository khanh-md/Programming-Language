To run the program, make sure Java and antlr4 is installed correctly.

Commands:

antlr4 pascal.g4 -visitor

javac VInterpreter.java pascal*.java Main.java

java Main tests/test*.pas


Test cases:
 - test1 demonstrate creation of class definition, constructor, destructor
 - test2 demonstrate encapsulation and show that private/protected variables cannot be accessed.