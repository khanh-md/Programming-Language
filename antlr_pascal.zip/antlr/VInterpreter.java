import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.util.*;

import java.util.regex.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VInterpreter extends pascalBaseVisitor<Object> {
    private Map<String, ClassDef> classes= new HashMap<>();
    private Map<String, ObjectInstance> objects = new HashMap<>();

    private Map<String, ParseTree> functions= new HashMap<>();
    private Map<String, String> values = new HashMap<>();

    private Map<String, List<String>> func_params = new HashMap<>();
    private Map<String, String> parameters= new HashMap<>();

    private List<String> encapsulation = new ArrayList<>();
    private List<String> methods = new ArrayList<>();

    private String c_name;
    

    // class ClassDef {
    //     private String name;

    //     public ClassDef(String name) { 
    //         this.name = name; 
    //     }
    // }
    class ClassDef {
        private String name;
        private ClassDef superClass;
    
        public ClassDef(String name, ClassDef superClass) {
            this.name = name;
            this.superClass = superClass;
        }
    
        public String getName() {
            return name;
        }
    
        public ClassDef getSuperClass() {
            return superClass;
        }
    }
    
    class ObjectInstance {
        private String className;
        private String value;
    
        public ObjectInstance(String className, String value) {
            this.className = className;
            this.value = value;
        }
    
        public String getString() { 
            return value; 
        }
        public String getClassName() { 
            return className; 
        }
    }

    @Override
    // public Object visitClassType(pascalParser.ClassTypeContext ctx) {
    //     String className = ctx.getParent().getChild(0).getText();
    //     classes.put(className, new ClassDef(className));
    
    //     String classBody = ctx.getChild(1).getText();
    //     String[] sections = classBody.split("(?<=;)(?=(private|protected|public|constructor|destructor))");

    //     //System.out.println("Sections after split: " + Arrays.toString(sections));

    //     for (String section : sections) {
    //         section = section.trim();  // Remove any surrounding whitespace

    //         // Only process sections that might contain variable declarations
    //         if (section.startsWith("private") || section.startsWith("protected")) {
    //             String[] declarations = section.replaceFirst("(private|protected)", "").trim().split(";");

    //             for (String declaration : declarations) {
    //                 String[] varParts = declaration.split(":");
    //                 if (varParts.length > 1) {
    //                     encapsulation.add(varParts[0].trim());
    //                 }
    //             }
    //         }
    //     }
    //     return null;
    // }

    public Object visitClassType(pascalParser.ClassTypeContext ctx) {
        String className = ctx.getParent().getChild(0).getText();
        String superClassName = null;
        if (ctx.inheritance() != null && ctx.inheritance().identifier() != null) {
            superClassName = ctx.inheritance().identifier().getText();
        }
        
        ClassDef superClass = (superClassName != null && classes.containsKey(superClassName))
                                ? classes.get(superClassName)
                                : null;

        // Store the new class with its superclass reference.
        ClassDef newClass = new ClassDef(className, superClass);
        classes.put(className, newClass);

        System.out.println("Class defined: " + className + 
                        (superClass != null ? " extends " + superClassName : ""));

        // Process class body for encapsulated variables
        String classBody = ctx.getChild(1).getText();
        String[] sections = classBody.split("(?<=;)(?=(private|protected|public|constructor|destructor))");

        for (String section : sections) {
            section = section.trim();

            if (section.startsWith("private") || section.startsWith("protected")) {
                String[] declarations = section.replaceFirst("(private|protected)", "").trim().split(";");
                for (String declaration : declarations) {
                    String[] varParts = declaration.split(":");
                    if (varParts.length > 1) {
                        encapsulation.add(varParts[0].trim());
                    }
                }
            }
        }

        // Inherit protected members from superclass (but not private members)
        if (superClass != null && superClassName != null) {
            // Use a temporary list to collect inherited variables.
            List<String> inheritedVars = new ArrayList<>();
            for (String inheritedVar : encapsulation) {
                if (inheritedVar.startsWith(superClassName + ".")) {
                    String varName = inheritedVar.substring(superClassName.length() + 1);
                    inheritedVars.add(varName);
                }
            }
            encapsulation.addAll(inheritedVars);
        }
        //System.out.println("Private/Protected Variables: " + encapsulation);
        return null;
    }


    @Override
    public Object visitConstructorDeclaration(pascalParser.ConstructorDeclarationContext ctx) {
        return processMethodDeclaration(ctx, "Create");
    }

    @Override
    public Object visitDestructorDeclaration(pascalParser.DestructorDeclarationContext ctx) {
        return processMethodDeclaration(ctx, "Destroy");
    }

    private Object processMethodDeclaration(ParserRuleContext ctx, String methodType) {
        String className = ctx.getChild(1).getText(); // Getting the identifier directly

        // Ensure the parent is a function declaration and retrieve the block
        if (ctx.getParent() instanceof pascalParser.FunctionDeclarationContext functionCtx &&
            functionCtx.block() != null) {
            
            functions.put(className + "." + methodType, functionCtx.block());
        } else {
            System.err.println("Error: " + methodType + " not found for " + className + "." + methodType);
        }
        
        return null;
    }

    @Override
    public Object visitFunctionDeclaration(pascalParser.FunctionDeclarationContext ctx) {
        String fName = extractFuncName(ctx);
    
        if (ctx.getText().contains("constructor")) {
            processConstructor(ctx);
        } else if (ctx.getText().contains("destructor")) {
            methods.add(ctx.identifier(1).getText());
        } else if (ctx.getText().contains("function")) {
            processFunction(ctx);
        }
    
        functions.put(fName, ctx.block());
        return null;
    }
    
    private String extractFuncName(pascalParser.FunctionDeclarationContext ctx) {
        return (ctx.identifier().size() > 1) 
                ? ctx.identifier(0).getText() + "." + ctx.identifier(1).getText() 
                : ctx.identifier(0).getText();
    }
    
    private void processConstructor(pascalParser.FunctionDeclarationContext ctx) {
        methods.add(ctx.identifier(1).getText());
    
        if (ctx.formalParameterList() != null) {
            for (int i = 1; i < ctx.formalParameterList().getChildCount(); i++) {
                String input = ctx.formalParameterList().getChild(i).getText();
                int index = input.indexOf(':');
                if (index != -1) {
                    String paramName = input.substring(0, index).trim();
                    func_params.putIfAbsent(ctx.identifier(0).getText(), new ArrayList<>());
                    func_params.get(ctx.identifier(0).getText()).add(paramName);
                }
            }
        }
    }
    
    private void processFunction(pascalParser.FunctionDeclarationContext ctx) {
        pascalParser.CompoundStatementContext compoundStmt = ctx.block().compoundStatement();
        
        if (compoundStmt != null) {
            Pattern pattern = Pattern.compile("(\\w+)\\s*:=\\s*(\\w+)");
            Matcher matcher = pattern.matcher(compoundStmt.statements().getText());
    
            while (matcher.find()) {
                parameters.put(ctx.identifier(1).getText(), matcher.group(2));
            }
        }
    }

    @Override
    public Object visitProcedureDeclaration(pascalParser.ProcedureDeclarationContext ctx) {
        String proName = ctx.identifier().getText();
        
        if (ctx.block() != null) {
            functions.put(proName, ctx.block());
        } else {
            System.err.println("Procedure '" + proName + "' has no defined body.");
        }
    
        return null;
    }

    @Override
    public Object visitAssignmentStatement(pascalParser.AssignmentStatementContext ctx) {
        String varName = ctx.variable().getText();
        String value = ctx.expression().getText();

        if (isConstructorCall(value)) {
            handleConstructorAssignment(varName, value);
        } else if (isDestructorCall(value)) {
            handleDestructorAssignment(varName);
        } else if (isMethodCall(value)) {
            handleMethodCall(varName, value);
        } else {
            handleVariableAssignment(varName, value);
        }

        return null;
    }

    private boolean isConstructorCall(String value) {
        return value.contains(methods.get(0));
    }

    private boolean isDestructorCall(String value) {
        return value.contains(methods.get(1));
    }

    private boolean isMethodCall(String value) {
        return value.contains(".") && value.contains("(");
    }

    
    private void handleConstructorAssignment(String varName, String value) {
        String[] parts = value.split("\\.");
        String className = parts[0];
        c_name = className;
    
        String constructorArgs = extractArguments(value);
        ObjectInstance obj = new ObjectInstance(className, constructorArgs);
        objects.put(varName, obj);
    
        assignConstructorParameters(className, constructorArgs);

        if (functions.containsKey(className + "." + methods.get(0))) {
            visit(functions.get(className + "." + methods.get(0)));
        }
    }
    
    private void assignConstructorParameters(String className, String constructorArgs) {
        List<String> paramNames = func_params.get(className);
        if (paramNames != null) {
            String[] paramValues = constructorArgs.split(",");
            for (int i = 0; i < paramValues.length; i++) {
                values.put(paramNames.get(i), paramValues[i]);
            }
        }
    }
    
    private void handleDestructorAssignment(String varName) {
        ObjectInstance obj = objects.get(varName);
        if (obj != null) {
            String destructorName = obj.getClassName() + "." + methods.get(1);
            if (functions.containsKey(destructorName)) {
                visit(functions.get(destructorName));
            }
            objects.remove(varName);
        }
    }
    
    // private void handleMethodCall(String varName, String value) {
    //     String functionName = extractFunctionName(value);
    
    //     if (functions.containsKey(c_name + "." + functionName)) {
    //         visit(functions.get(c_name + "." + functionName));
    //     }
    
    //     if (parameters.containsKey(functionName)) {
    //         String paramName = parameters.get(functionName);
    //         values.put(varName, values.get(paramName));
    //     }
    // }
    private void handleMethodCall(String varName, String value) {
        String functionName = extractFunctionName(value);
        ClassDef currentClass = classes.get(c_name);
    
        while (currentClass != null) {
            String fullMethodName = currentClass.getName() + "." + functionName;
    
            // Check if the method exists in this class or its ancestors
            if (functions.containsKey(fullMethodName)) {
                // Extract encapsulated variables before executing the method
                value = extractEncapsulatedValue(value);
                visit(functions.get(fullMethodName)); // Execute the method
                return;
            }
    
            // Move up to the superclass
            currentClass = currentClass.getSuperClass();
        }
    
        System.err.println("Error: Method " + functionName + " not found in class " + c_name + " or its superclasses.");
    }

    private void handleVariableAssignment(String varName, String value) {
        if (value.contains(".")) {
            value = extractEncapsulatedValue(value);
        }
    
        values.put(varName, values.getOrDefault(value, value));
    }
    
    private String extractArguments(String value) {
        return value.substring(value.indexOf("(") + 1, value.indexOf(")")).replace("'", "");
    }
    
    // private String extractFunctionName(String value) {
    //     String[] parts = value.split("\\.");
    //     return parts[1].replace("(", "").replace(")", "");
    // }
    private String extractFunctionName(String value) {
        String[] parts = value.split("\\.");
        if (parts.length > 1) {
            return parts[1].replace("(", "").replace(")", "");
        } else {
            // If there's no dot, return the value with any parentheses removed.
            return value.replace("(", "").replace(")", "");
        }
    }
    
    private String extractEncapsulatedValue(String value) {
        String[] parts = value.split("\\.");
        String extractedValue = parts[1];
 
        if (encapsulation.contains(extractedValue)) {
            System.err.println("Cannot access private/protected variable");
            return "";
        }
    
        return extractedValue;
    }
    
    
    @Override
    public Object visitFunctionDesignator(pascalParser.FunctionDesignatorContext ctx) {
        String objName = ctx.identifier(0).getText();
        String methodName = ctx.identifier(1).getText();
    
        ObjectInstance obj = objects.get(objName); // Single lookup
    
        if (obj != null && methodName.equals("GetString")) {
            return obj.getString();
        }
    
        return null;
    }
    
    @Override
    public Object visitProcedureStatement(pascalParser.ProcedureStatementContext ctx) {
        String procName = ctx.identifier().getText();
    
        if ("writeln".equals(procName)) {
            StringBuilder output = buildWritelnOutput(ctx);
            System.out.println(output.toString());
        }
    
        if (functions.containsKey(procName)) {
            visit(functions.get(procName));
        }
    
        return null;
    }
    
    private StringBuilder buildWritelnOutput(pascalParser.ProcedureStatementContext ctx) {
        StringBuilder output = new StringBuilder();
        pascalParser.ParameterListContext paramListCtx = ctx.parameterList();
    
        if (paramListCtx != null) {
            for (ParseTree param : paramListCtx.children) {
                String paramText = param.getText();
                output.append(processParameter(paramText));
            }
        }
    
        return output;
    }
    
    private String processParameter(String paramText) {
        if (paramText.startsWith("'") && paramText.endsWith("'")) {
            return paramText.substring(1, paramText.length() - 1);
        }
    
        if (values.containsKey(paramText)) {
            return values.get(paramText);
        }
    
        if (objects.containsKey(paramText)) {
            return objects.get(paramText).toString();
        }
    
        if (classes.containsKey(paramText)) {
            return classes.get(paramText).toString();
        }
    
        if (functions.containsKey(paramText)) {
            return "[Function: " + paramText + "]";
        }
    
        return ""; // default return if no match found
    }
    
}
