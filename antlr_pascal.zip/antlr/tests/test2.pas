program EncapsulationTest;

type
  Person = class
    private
      name: string;				    
	  protected
	    age: Integer;
    public
		  count: Integer;
      constructor Create(S: string);
      destructor Destroy;
  end;

constructor Person.Create(S: string; a:Integer; p:Integer);
begin
  name := S;
	age:=a;
  count:=p;
  
end;

destructor Person.Destroy();
begin
    writeln('Destroy object');
    
end;

var
  p: Person;

begin
  p := Person.Create('John Doe', 32, 15); 
  writeln('Encapsulation Features');
  n:=p.name;
  a:=p.age;
  count:=p.count;
  writeln('Public variable count: ', count);
  p := Person.Destroy();

end.
