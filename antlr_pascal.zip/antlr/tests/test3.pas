program InheritanceTest;

type
  TAnimal = class
    private
      secret: string;
    protected
      species: string;
    public
      name: string;
      constructor Create(S: string; n: string; p: string);
      destructor Destroy;
  end;

  TDog = class(TAnimal)
    public
      breed: string;
      constructor Create(S: string; B: string);
      destructor Destroy;
  end;

constructor TAnimal.Create(S: string; n: string; p: string);
begin
  name := S;
  species := n;
  secret := p;
end;

destructor TAnimal.Destroy();
begin
  writeln('Destroying Animal');
end;

constructor TDog.Create(S: string; B: string);
begin
  name := S
  breed := B;
end;

destructor TDog.Destroy();
begin
  writeln('Destroying Dog');
end;

var
  animal: TAnimal;
  dog: TDog;
  aname, dname, db, as: string; 

begin
  animal := TAnimal.Create('Generic Animal', 'Mammal', 'Secret');
  dog := TDog.Create('Buddy', 'Labrador');

  aname := animal.name;
  as := animal.secret;  
  dname := dog.name;
  db := dog.breed;

  writeln('Inheritance Features');
  writeln('Animal: ', aname);
  writeln('Dog: ', dname, ', Breed: ', db);

  animal.Destroy;
  dog.Destroy;
end.
