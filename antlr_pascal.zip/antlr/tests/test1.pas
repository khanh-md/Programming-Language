program testClass;
type
  Person = class
    private
        name: string;		    	
    public		
        constructor Create(S: string);
        destructor Destroy;
  end;


constructor Person.Create(S: string);
begin
    name := S;
    writeln(name);
end;

destructor Person.Destroy();
begin
    writeln('Destroy object');
    
end;

var
  p: Person;

begin
  p := Person.Create('Create object'); 
  p := Person.Destroy();

end.
