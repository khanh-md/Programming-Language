import java.lang.Exception;
import java.nio.charset.StandardCharsets;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.*;

public class Main {

    public static void main(String[] args) throws Exception {
        String inputFile = null;
        if (args.length > 0) inputFile = args[0];

        CharStream input;
        if (inputFile != null) {
            input = CharStreams.fromPath(new File(inputFile).toPath(), StandardCharsets.UTF_8);
        } else {
            input = CharStreams.fromStream(System.in, StandardCharsets.UTF_8);
        }

        pascalLexer lexer = new pascalLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        pascalParser parser = new pascalParser(tokens);
        ParseTree tree = parser.program();

        VInterpreter interpreter = new VInterpreter();
        interpreter.visit(tree);
    }
}